var rightFrame = document.getElementsByName('rightFrame')[0];
rightFrame.onload = function() {
    var closeButton = document.getElementById('closeButton');
    if (rightFrame.contentWindow.location.href !== '/homeright') {
        closeButton.style.display = 'block';
    } else {
        closeButton.style.display = 'none';
    }
};
    
function clearIframe() {
    var iframe = document.getElementsByName('rightFrame')[0];
    iframe.src = 'homeright.html';
    document.getElementById('closeButton').style.display = 'none';
}

