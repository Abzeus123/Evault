const DigitalContract = artifacts.require("DigitalContract");

module.exports = function(deployer) {
  deployer.deploy(DigitalContract);
};
