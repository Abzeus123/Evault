from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('',views.login, name="login"),
    path('login/', views.login, name = "login"),
    path('signup/', views.signup, name = "signup"),
    path('home/',views.home,name="home"),
    path('upload/',views.upload,name="upload"),
    path('forgot_password/',views.forgot_password,name="forgot_password"),
    path('existingupload/',views.existingupload,name="existingupload"),
    path('lawyer/',views.lawyer,name="lawyer"),
    path('homeright/',views.homeright,name="homeright"),
    path('guidance/',views.guidance,name="guidance"),
    path('lawyersearch/',views.lawyersearch,name="lawyersearch"),
    path('mycases/',views.mycases,name="mycases"),
    path('forgot_username/',views.forgot_username,name="forgot_username"),
    path('audio/',views.audio,name="audio"),
    path('adminpage/',views.adminpage,name="adminpage"),
    path('vakalat/',views.vakalat,name="vakalat"),
    path('addlawyer/',views.addlawyer,name="addlawyer"),
    path('review/',views.review,name="review"),
    path('newcase/',views.newcase,name="newcase"),
    path('changehearingdate/',views.changehearingdate,name="changehearingdate"),
    path('judgement/',views.judgement,name="judgement"),
    path('evidenceupload/',views.evidenceupload,name="evidenceuploads"),
    path('supportrole/',views.supportrole,name="supportrole"),
    path('bail/',views.bail,name="bail"),
    path('aid/',views.aid,name="aid"),
]