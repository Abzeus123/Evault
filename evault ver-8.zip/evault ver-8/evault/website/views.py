from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as d_login
from django.contrib import messages
from django.core.mail import send_mail
import pymongo
from datetime import date
from .models import governmentdb
import uuid
import os
from django.core.files.storage import default_storage
from azure.storage.blob import BlobServiceClient
from web3 import Web3
import json
from web3 import Web3
from datetime import datetime



def handle_exception():
    response_data = {
        'redirect': True
    }
    return HttpResponse(
        f"""
        <script>
            setTimeout(function() {{
                window.location.href = "/login";
            }}, 1000);
        </script>
        <p>Sorry for the inconvenience. Redirecting to the login page...</p>
        <p>If you are not automatically redirected, <a href="/login">click here</a>.</p>
        """,
        content_type="text/html"
    )

def get_todays_date():
    today = datetime.today()
    formatted_date = today.strftime('%d-%m-%Y')
    return formatted_date


client = pymongo.MongoClient()
db = client['myDb']
col3 = db['docs']
col = db['casedetails']
lawyer_db = db['lawyers']
review_db = db['review']
web3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545')) 
today_date = date.today()

identity_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/IdentityManagement.json'
with open(identity_artifact_path, 'r') as f:
    identity_contract_artifact = json.load(f)
identity_contract_abi = identity_contract_artifact['abi']
identity_contract_address = '0x6449550a56B744AAaED346E18ecBcFFfAD32B165' 
identity_contract = web3.eth.contract(address=identity_contract_address, abi=identity_contract_abi)
web3.eth.default_account = web3.eth.accounts[0] 
def login(request):
    global noofcases
    global username
    global name
    global unique_id
    global role
    if request.method == "POST":
        username = request.POST['name']
        password = request.POST['password']
        unique_id = username
        user = authenticate(username=username, password=password)
        if user:
            temp = governmentdb.objects.filter(UID=username)[0].name
            name = temp[0].upper() + temp[1:].lower()
            email = governmentdb.objects.filter(UID=username)[0].email
            send_mail('Account Logged in',f'You are now signed into your Evault account.Please disregard if it is you; if not, report the incident by sending an email to ragav2706@gmail.com. ','anuragav754@gmail.com',[email],fail_silently=True)
            d_login(request,user)
            role = governmentdb.objects.filter(email=email)[0].role
            if role == "admin":
                return redirect('/adminpage')
            elif role in ["police", "analyst"]:
                return redirect("/supportrole")
            else:
                return redirect("/home/?name={}&uid={}&role={}".format(name, username, role))
        else:
            messages.info(request,"Wrong Credentials! Try Again")
            return redirect('/login')
    return render(request, 'website/login.html')

def signup(request):
    global noofcases
    global email
    global name
    global username
    global unique_id
    global role
    noofcases=0
    identity_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/IdentityManagement.json'
    with open(identity_artifact_path, 'r') as f:
        identity_contract_artifact = json.load(f)
    identity_contract_abi = identity_contract_artifact['abi']
    identity_contract_address = '0x6449550a56B744AAaED346E18ecBcFFfAD32B165' 
    identity_contract = web3.eth.contract(address=identity_contract_address, abi=identity_contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['mail']
        password = request.POST['password']
        aadharno = request.POST['aadharno']
        contact = int(request.POST['contact'])
        if len(governmentdb.objects.filter(aadharno=aadharno)) == 0:
            messages.error(request, "Please check your Aadhar number")
            return redirect("/signup")
        db_number = governmentdb.objects.filter(aadharno=aadharno)[0].phoneno
        db_mail = governmentdb.objects.filter(aadharno=aadharno)[0].email
        role = role = governmentdb.objects.filter(aadharno=aadharno )[0].role
        print(db_number == contact,db_mail == email)
        if User.objects.filter(email=email).count() > 0:
            messages.error(request,"User Already Exists! Signin To Your Account")
            return redirect('/login')
        elif db_number == contact and db_mail == email:
            name = name[0].upper() + name[1:].lower()
            unique_id = 'C' + uuid.uuid4().hex.upper()[:9]
            username=unique_id
            user = User.objects.create_user(username=unique_id,email=email, password=password)
            user.save()  
            government_entry = governmentdb.objects.get(aadharno=aadharno)
            government_entry.UID = username
            government_entry.username = name
            government_entry.save()
            send_mail('Account Created Successfully',f'We are excited for your journey with us! Expect tailored updates, exclusive content, and dedicated support. '+str(unique_id),'anuragav754@gmail.com',[email],fail_silently=False)
            user_details = governmentdb.objects.get(aadharno=aadharno)
            _name = user_details.name
            _email = user_details.email
            _contact = int(user_details.phoneno) 
            _aadhar = str(user_details.aadharno)    
            _dob = user_details.dob.strftime('%Y-%m-%d')
            _uid = unique_id
            _username = name
            _role = user_details.role
            _status = "alive"
            _password = password
            tx_hash = identity_contract.functions.addUser(
                        _name, _email, _contact, _aadhar, _dob, _uid, _username, _role, _status, _password
                    ).transact()

            return redirect("/home/?name={}&uid={}&cases={}".format(name,unique_id,noofcases))

        else:
            messages.error(request,"Wrong Credentials")

    return render(request, 'website/signup.html')

def forgot_password(request):
    if request.method=="POST":
        aadharno = request.POST['aadharno']
        if governmentdb.objects.filter(aadharno=aadharno).count()==0:
            messages.error(request,"Please Check Your Aadhar Number")
        else:
            usermail = governmentdb.objects.filter(aadharno=aadharno)[0].email
            send_mail('Reset Password',f' We heard that you lost your Vault password. Sorry about that.But don’t worry! You can use the following OTP to reset your password: '+str(1234)+"This OTP is valid only for 5 mintues",'anuragav754@gmail.com',[usermail],fail_silently=True)
            return redirect("/login")
    return render(request,'website/forgot_password.html')    

def forgot_username(request):
    if request.method=="POST":
        aadharno = request.POST['aadharno']
        if governmentdb.objects.filter(aadharno=aadharno).count()==0:
            messages.error(request,"Please Check Your Aadhar Number")
        else:
            usermail = governmentdb.objects.filter(aadharno=aadharno)[0].email
            uid = governmentdb.objects.filter(aadharno=aadharno)[0].UID
            send_mail('Site Username',f' We heard that you lost your Vault username. Sorry about that.But don’t worry!'+str(uid)+"is your username. Use this to login to our site.",'anuragav754@gmail.com',[usermail],fail_silently=True)
            return redirect("/login")
    return render(request,"website/forgot_username.html")

def home(request):
    try:
        role = governmentdb.objects.filter(UID=username)[0].role
        name = governmentdb.objects.filter(UID=username)[0].name
        if role == "citizen":
            filter_query = {"$or": [{"Petitioner": username}, {"Defendant": username}]}
        elif role == "lawyer":
            filter_query = {"$or": [{"Petitioner_lawyer": username}, {"Defendant_lawyer": username}]}
        elif role == "judge":
            filter_query = {"Judge": username}
        result = list(col.find(filter_query))
        if len(result) == 0:
            case = 0
        else:
            case = 1
        return render(request, "website/homepage.html", {'role': role, 'name': name, 'case': case})
    except Exception as e:
        return handle_exception()

def homeright(request):
    global citizen_type
    citizen_type = None
    caseid = request.GET.get('caseid', '0')  
    rec = None
    documents = None
    case_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/CaseManagement.json'
    with open(case_artifact_path, 'r') as f:
        case_contract_artifact = json.load(f)
    case_contract_abi = case_contract_artifact['abi']
    case_contract_address = '0x128B7BF8fe5055919300e9602E09eDFD311747fe' 
    case_contract = web3.eth.contract(address=case_contract_address, abi=case_contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    if caseid != '0':
        rec = col.find_one({'Case_id': int(caseid)})
        if rec:
            citizen_type = 1 if col.find_one({"Petitioner": username}) else 2
            documents = col3.find({"Case_id": int(caseid)})
    
    if request.method == "POST":
        case_no = int(request.POST.get('caseid'))
        document_name = request.POST.get('document_name')
        status = request.POST.get('status')
        if document_name and status:
            col3.update_one({"file_name": document_name}, {"$set": {"status": status}})
            case_contract.functions.changeDocumentStatus(
                    case_no,status
                            ).transact()
    
    return render(request, "website/homeright.html", {'caseid': caseid, 'rec': rec, 'role': role, 'citizen_type': citizen_type, 'documents': documents})


def mycases(request):
    try:
        role = governmentdb.objects.filter(UID=username)[0].role
        print(role)
        if role == "citizen":
            filter_query = {"$or": [{"Petitioner": username}, {"Defendant":username}]}
        elif role == "lawyer":
            filter_query = {"$or": [{"Petitioner_lawyer": username}, {"Defendant_lawyer": username}]}
        elif role == "judge":
            filter_query = {"Judge": username}
        
        result = col.find(filter_query)
        print(result)
        return render(request, "website/mycases.html", {'result': result, 'role': role, 'name': name})
    except Exception as e:
        return handle_exception()
    

def existingupload(request):
    if request.method == 'POST' and request.FILES['document']:
        case_no = int(request.POST['case_no'])
        document = request.FILES['document']
        container_name = 'evault'
        azure_storage_path = os.path.join(container_name, str(case_no), document.name)
        blob_service_client = BlobServiceClient.from_connection_string('DefaultEndpointsProtocol=https;AccountName=recordstorage123;AccountKey=gpB6AUB9T1fGqgGokWH/RD8yi4sfdJJUybtdJN/+fi2yI8CD8t7kj65h79kT1DqxzgHw8W81D/h0+ASto9puoA==;EndpointSuffix=core.windows.net')
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=azure_storage_path)
        try:
            blob_client.upload_blob(document)
            case_id = int(request.POST['case_no'])
            file_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{azure_storage_path}"
            print("$$$$$$$$$$$$$$$$$$$$$$",file_url)

            print(case_id)
            col.update_one({'case_id': case_id}, {'$push': {'file_urls': file_url}})          

            return HttpResponse(f'File Uploaded')
        except Exception as e:
            return HttpResponse(f'Error uploading document: {e}')
    
    return render(request, "website/existingupload.html")

def upload(request):
    if request.method == 'POST' and request.FILES['document']:
        case_no = int(request.POST['case_no'])
        peti_id = request.POST['petitioner']
        defen_id = request.POST['defendant']
        jurisdiction = request.POST['jurisdiction']
        document = request.FILES['document']  
        container_name = 'evault'
        storage_path = os.path.join(container_name,str(case_no))
        azure_storage_path = os.path.join(container_name,str(case_no),document.name)
        blob_service_client = BlobServiceClient.from_connection_string('DefaultEndpointsProtocol=https;AccountName=recordstorage123;AccountKey=gpB6AUB9T1fGqgGokWH/RD8yi4sfdJJUybtdJN/+fi2yI8CD8t7kj65h79kT1DqxzgHw8W81D/h0+ASto9puoA==;EndpointSuffix=core.windows.net')
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=azure_storage_path)
        try:

            blob_client.upload_blob(document)
            document_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{storage_path}"
            artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/CaseManagement.json'
            with open(artifact_path, 'r') as f:
                contract_artifact = json.load(f)
            contract_abi = contract_artifact['abi']
            contract_address = '0xE138555590427933ae6C215CD404F7a5f930d489' 
            contract = web3.eth.contract(address=contract_address, abi=contract_abi)
            web3.eth.default_account = web3.eth.accounts[0] 
            contract.functions.addCase(
                        case_no, peti_id, defen_id,username,jurisdiction,document_url).transact()
            return HttpResponse('Document uploaded successfully!')
        except Exception as e:
            return HttpResponse(f'Error uploading document: {e}')
    return render(request,"website/upload.html",{'name':name})




def guidance(request):
    try:
        return render(request, "website/guidancepage.html", {'name': name, 'role': role})
    except Exception as e:
        return handle_exception()


def newcase(request):
    try:
        case_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/CaseManagement.json'
        with open(case_artifact_path, 'r') as f:
            case_contract_artifact = json.load(f)
        case_contract_abi = case_contract_artifact['abi']
        case_contract_address = '0x128B7BF8fe5055919300e9602E09eDFD311747fe' 
        case_contract = web3.eth.contract(address=case_contract_address, abi=case_contract_abi)
        web3.eth.default_account = web3.eth.accounts[0] 
        if request.method=="POST":
            case_type = request.POST['case_type']
            case_no = int(request.POST['case_no'])
            petitioner = request.POST['petitioner']
            peti_lawyer = request.POST['peti_lawyer']
            defendant = request.POST['defendant']
            defen_lawyer = request.POST['defen_lawyer']
            court = request.POST['jurisdiction']
            statement = request.POST['statement']
            hearing_date = request.POST['hearing_date']

            user_roles = {
                'petitioner': identity_contract.functions.checkRole(petitioner).call(),
                'peti_lawyer': identity_contract.functions.checkRole(peti_lawyer).call(),
                'defendant': identity_contract.functions.checkRole(defendant).call(),
                'defen_lawyer': identity_contract.functions.checkRole(defen_lawyer).call(),
                'judge': identity_contract.functions.checkRole(username).call()
            }

            if all(role == 'citizen' for role in [user_roles['petitioner'], user_roles['defendant']]) and \
                all(role == 'lawyer' for role in [user_roles['peti_lawyer'], user_roles['defen_lawyer']]) and \
                user_roles['judge'] == 'judge':
                if col.find_one({"Case_id": case_no}):
                    response_data = {'redirect': True}
                    return HttpResponse(
                        f"""
                        <script>
                            setTimeout(function() {{
                                window.location.href = "/home";
                            }}, 2000);
                        </script>
                        <p>Case ID already exists. Redirecting to the home page...</p>
                        <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                        """,
                        content_type="text/html"
                    )

                pipeline = [{"$group": {"_id": None,"maxFilingNumber": {"$max": "$Filing_number"}}}]
                result = list(col.aggregate(pipeline))
                max_filing_number = result[0]["maxFilingNumber"] if result else 5000
                Filing_number = max_filing_number + 1
                Filing_date = get_todays_date()
                judge = username
                status = "Numbered"
                newcase_data = {
                    'Case_type': case_type,
                    'Filing_number' : Filing_number,
                    'Filing_date': Filing_date,
                    'Case_id': case_no,
                    'Statement' : statement,
                    'Petitioner' : petitioner,
                    'Petitioner_lawyer' : peti_lawyer,
                    'Defendant' : defendant,
                    'Defendant_lawyer' : defen_lawyer,
                    'Court' : court,
                    'First_hearing_date ' : hearing_date,
                    'Next_hearing_date': hearing_date,
                    'Status' : status,
                    'Judge' : judge
                }
                case_contract.functions.createCase(
                                case_no, petitioner, peti_lawyer, defendant, defen_lawyer, court, judge, hearing_date, hearing_date
                            ).transact()

                col.insert_one(newcase_data)
                response_data = {'redirect': True}
                return HttpResponse(
                        f"""
                        <script>
                            setTimeout(function() {{
                                window.location.href = "/home";
                            }}, 5000);
                        </script>
                        <p>Case ID Updated. Redirecting to the home page...</p>
                        <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                        """,
                        content_type="text/html"
                    )
            else:
                return HttpResponse("Check the data properly")
    except ValueError as e:
        return handle_exception()
    return render(request,"website/newcase.html",{'role':role,'name':name})

def changehearingdate(request):
    if request.method=="POST":
        case_no = request.POST['case_no']
        hearing_date = request.POST['hearing_date']
        if  not col.find_one({"Case_id": case_no}):
            response_data = {
                'redirect': True
            }
            return HttpResponse(
                f"""
                <script>
                    setTimeout(function() {{
                        window.location.href = "/home";
                    }}, 5000);
                </script>
                <p>Case ID Not Found. Redirecting to the home page...</p>
                <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                """,
                content_type="text/html"
            )
        else:
            col.update_one({"Case_id": case_no},{"$set": {"Next_hearing_date": hearing_date}}
)
            response_data = {
                'redirect': True
            }
            return HttpResponse(
                f"""
                <script>
                    setTimeout(function() {{
                        window.location.href = "/home";
                    }}, 2000);
                </script>
                <p>Date Changed. Redirecting to the home page...</p>
                <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                """,
                content_type="text/html"
            )
    return render(request,"website/changehearingdate.html",{'role':role,'name':name})


def judgement(request):
    case_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/CaseManagement.json'
    with open(case_artifact_path, 'r') as f:
        case_contract_artifact = json.load(f)
    case_contract_abi = case_contract_artifact['abi']
    case_contract_address = '0x128B7BF8fe5055919300e9602E09eDFD311747fe' 
    case_contract = web3.eth.contract(address=case_contract_address, abi=case_contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    if request.method == "POST" and request.FILES.get('document'):
        case_no = int(request.POST.get('case_no'))
        judgement = request.POST.get('judgement')
        document = request.FILES['document']
        container_name = 'evault'
        azure_storage_path = os.path.join(container_name, str(case_no), document.name)
        blob_service_client = BlobServiceClient.from_connection_string('DefaultEndpointsProtocol=https;AccountName=recordstorage123;AccountKey=gpB6AUB9T1fGqgGokWH/RD8yi4sfdJJUybtdJN/+fi2yI8CD8t7kj65h79kT1DqxzgHw8W81D/h0+ASto9puoA==;EndpointSuffix=core.windows.net')
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=azure_storage_path)  

        existing_case = col.find_one({"Case_id": case_no})
        if not existing_case:
            response_data = {
                'redirect': True
            }
            return HttpResponse(
                f"""
                <script>
                    setTimeout(function() {{
                        window.location.href = "/home";
                    }}, 2000);
                </script>
                <p>Case ID Not Found. Redirecting to the home page...</p>
                <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                """,
                content_type="text/html"
            )
        elif existing_case.get("Judgement", ""):
            response_data = {
                'redirect': True
            }
            return HttpResponse(
                f"""
                <script>
                    setTimeout(function() {{
                        window.location.href = "/home";
                    }}, 2000);
                </script>
                <p>Judgement already given. Redirecting to the home page...</p>
                <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                """,
                content_type="text/html"
            )
        else:
            try:
                blob_client.upload_blob(document)
                col.update_one(
                    {"Case_id": case_no},
                    {"$push": {"files": {document.name: 3}}}
                )
                col.update_one({"Case_id": case_no}, {"$set": {"Judgement": judgement}})
                case_contract.functions.updateJudgement(
                                case_no,judgement
                            ).transact()
                case_contract.functions.updateCaseStatus(
                                case_no,"Completed"
                            ).transact()
                col.update_one({"Case_id": case_no}, {"$set": {"Status": "Completed"}})
                
                response_data = {
                    'redirect': True
                }
                return HttpResponse(
                    f"""
                    <script>
                        setTimeout(function() {{
                            window.location.href = "/home";
                        }}, 2000);
                    </script>
                    <p>Judgement Saved. Redirecting to the home page...</p>
                    <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                    """,
                    content_type="text/html"
                )
            except Exception as e:
                return HttpResponse(f'Error uploading document: {e}')
    return render(request, "website/judgement.html", {'role': role, 'name': name})




def evidenceupload(request):
    case_artifact_path = 'C:/Users/Asus/Desktop/evault ver-8/evault/build/contracts/CaseManagement.json'
    with open(case_artifact_path, 'r') as f:
        case_contract_artifact = json.load(f)
    case_contract_abi = case_contract_artifact['abi']
    case_contract_address = '0x128B7BF8fe5055919300e9602E09eDFD311747fe' 
    case_contract = web3.eth.contract(address=case_contract_address, abi=case_contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    if request.method == "POST" and request.FILES.get('document'):
        case_no = int(request.POST.get('case_no'))
        document = request.FILES['document']
        container_name = 'evault'
        azure_storage_path = os.path.join(container_name, str(case_no), document.name)
        blob_service_client = BlobServiceClient.from_connection_string('DefaultEndpointsProtocol=https;AccountName=recordstorage123;AccountKey=gpB6AUB9T1fGqgGokWH/RD8yi4sfdJJUybtdJN/+fi2yI8CD8t7kj65h79kT1DqxzgHw8W81D/h0+ASto9puoA==;EndpointSuffix=core.windows.net')
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=azure_storage_path)
        client = pymongo.MongoClient()
        db = client['myDb']
        col3 = db['docs']
        if role =="lawyer":
            lawyer_type = None
            case_details = col.find_one({"Case_id": case_no})
            if case_details:
                if username == case_details['Petitioner_lawyer']:
                    lawyer_type = 1  
                elif username == case_details['Defendant_lawyer']:
                    lawyer_type = 2 
                else:
                    lawyer_type = 5
        if not col.find_one({"Case_id": case_no}):
            response_data = {'redirect': True}
            return HttpResponse(
                f"""
                <script>
                    setTimeout(function() {{
                        window.location.href = "/home";
                    }}, 2000);
                </script>
                <p>Case ID Not Found. Redirecting to the home page...</p>
                <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                """,
                content_type="text/html"
            )
        else:
            try:
                blob_client.upload_blob(document)                
                col.update_one(
                    {"Case_id": case_no},
                    {"$push": {"files": {document.name: lawyer_type}}}
                )
                col3.insert_one({"Case_id":case_no,"file_name":document.name,"status":"Pending"})
                case_contract.functions.addDocument(
                                unique_id,document.name,case_no,azure_storage_path
                            ).transact()
                response_data = {'redirect': True}
                return HttpResponse(
                    f"""
                    <script>
                        setTimeout(function() {{
                            window.location.href = "/home";
                        }}, 2000);
                    </script>
                    <p>Evidence Uploaded. Redirecting to the home page...</p>
                    <p>If you are not automatically redirected, <a href="/home/?name={name}&uid={username}&role={role}">click here</a>.</p>
                    """,
                    content_type="text/html"
                )
            except Exception as e:
                return HttpResponse(f'Error uploading document: {e}')
    return render(request, "website/evidenceupload.html", {'role': role, 'name': name})

def lawyersearch(request):
    name = governmentdb.objects.filter(UID=unique_id)[0].name
    role = governmentdb.objects.filter(UID=unique_id)[0].role
    if request.method=="POST":
        expertise = request.POST['expertise']
        location = request.POST['location']
        experience = int(request.POST['experience'])  
        rating = int(request.POST['rating'])  
        findings = lawyer_db.find({"location": location,"expertise": expertise,"rating": { "$gt": rating },"experience": { "$gt": experience }})
        global f
        f=[]
        for i in findings:
            a={}
            a['id']=i['_id']
            a['name']=i['name']
            a['age']=i['age']
            a['contact']=i['contact']
            a['experience']=i['experience']
            a['expertise']=i['expertise']
            a['total_cases']=i['total_cases']
            a['number_of_cases_accuted']=i['number_of_cases_accuted']
            a['location_url']=i['location_url']
            a['rating']=i['rating']
            a['email']=i['email'] 
            f.append(a)
        return redirect("/lawyer/?name={}&role={}".format(name,role))
    return render(request,"website/lawyersearch.html",{'name':name})



def review(request):
    if request.method == 'GET' and 'lawyer_id' in request.GET:
        lawyer_id = request.GET.get('lawyer_id')
        reviews = review_db.find({"lawyer_id": lawyer_id})
        reviewlist = []
        for i in reviews:
            a = {}
            a['user'] = i['user']
            a['rating'] = i['rating']
            a['comment'] = i['comment']  
            reviewlist.append(a)
        return render(request, "website/review.html", {'reviews': reviewlist,'role':role,'name':name})


def lawyer(request):
    if request.method == 'POST':
        lawyer_id = request.POST.get('lawyer_id')
        print(lawyer_id)
        rating = int(request.POST.get('rating'))
        comment = request.POST.get('comment')
        print(rating)
        review_data = {
            'lawyer_id': lawyer_id,
            'user' : name,
            'rating': rating,
            'comment': comment
        }
        review_db.insert_one(review_data)
    return render(request,"website/lawyers.html",{'data':f})

def audio(request):
    return render(request,"website/audio.html")

def adminpage(request):
    return render(request,"website/adminpage.html")

def vakalat(request):
    artifact_path = r'C:\Users\Asus\Desktop\evault ver-8\evault\build\contracts\DigitalContract.json'
    with open(artifact_path, 'r') as f:
        contract_artifact = json.load(f)
    vakalat_contract_abi = contract_artifact['abi']
    vakalat_contract_address = '0x2D2E0758E8d98fFF05A5F8D555F2E47fbe8A1c9f' 
    vakalat_contract = web3.eth.contract(address=vakalat_contract_address, abi=vakalat_contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    transaction_parameters = {
    'from': web3.eth.default_account,  
    'gasPrice': web3.eth.gas_price,   
    'gas': 5000000000,                     
}
    tx_hash = vakalat_contract.functions.addBail(
        'a', 'a', 'a', 'a', 'a', 'a', 1, 'a'
    ).transact(transaction_parameters)
    tx_hash = vakalat_contract.functions.addAid(
        'a', 'a', 'a', 'a', 'a', 1, 'a'
    ).transact(transaction_parameters)

    if request.method=="POST":
        petitioner = request.POST['petitioner']
        lawyer = request.POST['lawyer']
        judge = request.POST['judge']
        court = request.POST['court']
        case_no = int(request.POST['case_no'])
        vakalat_contract.functions.addVakalat(petitioner, lawyer, court, judge,'15-04-2024', case_no).transact(transaction_parameters)
        return HttpResponse("Vakalat is submitted")
    return render(request,"website/vakalat.html", {'role':role,'name':name})

def addlawyer(request):
    return render(request,"website/addlawyer.html")

def supportrole(request):
    return render(request,"website/supportrole.html")


def bail(request):
    artifact_path = r'C:\Users\Asus\Desktop\evault ver-8\evault\build\contracts\DigitalContract.json'
    with open(artifact_path, 'r') as f:
        contract_artifact = json.load(f)
    contract_abi = contract_artifact['abi']
    contract_address = '0x2D2E0758E8d98fFF05A5F8D555F2E47fbe8A1c9f' 
    contract = web3.eth.contract(address=contract_address, abi=contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    transaction_parameters = {
        'from': web3.eth.default_account, 
        'gasPrice': web3.eth.gas_price,    
        'gas': 5000000000,                     
    }
    if request.method == "POST":
        try:
            petitioner = request.POST['petitioner']
            lawyer = request.POST['lawyer']
            allegation = request.POST['allegation']
            livelihood = request.POST['livelihood']
            judge = request.POST['judge']
            court = request.POST['court']
            case_no = int(request.POST['case_no'])
            
            try:
                user_roles = {
                    'petitioner': identity_contract.functions.checkRole(petitioner).call(),
                    'lawyer': identity_contract.functions.checkRole(lawyer).call(),
                    'judge': identity_contract.functions.checkRole(judge).call()
                }
            except ValueError:
                return HttpResponse("User not found")
            
            if user_roles['petitioner'] == 'citizen' and user_roles['lawyer'] == 'lawyer' and user_roles['judge'] == 'judge':
                if col.find_one({"Case_id": case_no}):
                    contract.functions.addBail(petitioner, lawyer, allegation, livelihood, judge, court, case_no, "Pending").transact(transaction_parameters)
                    return HttpResponse("Bail is submitted")
                else:
                    return HttpResponse("Case not found")
            else:
                return HttpResponse("Check user roles properly")
        except Exception as e:
            print("Error:", e)
            return HttpResponse("Upload successful")
    return render(request, "website/bail.html")

def aid(request):
    artifact_path = r'C:\Users\Asus\Desktop\evault ver-8\evault\build\contracts\DigitalContract.json'
    with open(artifact_path, 'r') as f:
        contract_artifact = json.load(f)
    contract_abi = contract_artifact['abi']
    contract_address = '0x2D2E0758E8d98fFF05A5F8D555F2E47fbe8A1c9f' 
    contract = web3.eth.contract(address=contract_address, abi=contract_abi)
    web3.eth.default_account = web3.eth.accounts[0] 
    transaction_parameters = {
        'from': web3.eth.default_account, 
        'gasPrice': web3.eth.gas_price,    
        'gas': 5000000000,                     
    }
    if request.method == "POST":
        try:
            petitioner = request.POST['petitioner']
            lawyer = request.POST['lawyer']
            reason = request.POST['reason']
            judge = request.POST['judge']
            court = request.POST['court']
            case_no = int(request.POST['case_no'])
            try:
                user_roles = {
                    'petitioner': identity_contract.functions.checkRole(petitioner).call(),
                    'lawyer': identity_contract.functions.checkRole(lawyer).call(),
                    'judge': identity_contract.functions.checkRole(judge).call()
                }
            except ValueError:
                return HttpResponse("User not found")
            
            if user_roles['petitioner'] == 'citizen' and user_roles['lawyer'] == 'lawyer' and user_roles['judge'] == 'judge':
                if col.find_one({"Case_id": case_no}):
                    contract.functions.addAid(petitioner, lawyer, judge,reason, court, case_no, "Pending").transact(transaction_parameters)
                    return HttpResponse("Aid is submitted")
                else:
                    return HttpResponse("Case not found")
            else:
                return HttpResponse("Check user roles properly")
        except Exception as e:
            print("Error:", e)
            return HttpResponse("Upload successful")
    return render(request, "website/aid.html")
