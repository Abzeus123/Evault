from django.contrib import admin
from .models import governmentdb
admin.site.register(governmentdb)
