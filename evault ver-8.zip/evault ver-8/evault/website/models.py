from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

status=(
    ('ALIVE','Alive'),
    ('DEAD','Dead'),
)   
class governmentdb(models.Model):
    name = models.CharField(max_length=50)
    dob = models.DateField()
    image = models.ImageField(blank=True)
    email = models.EmailField(null=True)
    phoneno = models.IntegerField()
    aadharno = models.IntegerField()
    status = models.CharField(max_length=10,choices=status)
    UID = models.CharField(max_length=50,null=True,blank=True)
    username = models.CharField(max_length=50,null=True,blank=True)
    role = models.CharField(max_length=15,default="citizen")

    def __str__(self):
        return f"{self.aadharno}"
    


class MyModel(models.Model):
    file = models.FileField(upload_to='https://evaultproject.blob.core.windows.net/evault')